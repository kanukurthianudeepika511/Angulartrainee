import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  updatetrainee: Trainees;
  constructor(private httpService: HttpClient) { }
  public getTrainees() {
    console.log("ins service get trainees");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Trainees>("http://localhost:9999/trainee/getall");
  }

  public addEmp(addemp: Trainees) {
    console.log("ins service add");
    console.log(addemp);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:9999/trainee/add", addemp,  { headers, responseType: 'text'});
  }
  
  public update(updateemployee: Trainees) {
    this.updatetrainee = updateemployee;
  }
  public updateMethod() {
    return this.updatetrainee;
  }
  public onUpdate(updatemp: Trainees) {
    console.log("ins service update");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.put("http://localhost:9999/trainee/update", updatemp,  { headers, responseType: 'text'});
  }
  delete(id: number) {
    console.log("ins service delete");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.delete("http://localhost:9999/trainee/delete" + id,  { headers, responseType: 'text'});
  }

}
export class Trainees {
  id: number;
  name: string;
  location: string;
  domain: string;
}